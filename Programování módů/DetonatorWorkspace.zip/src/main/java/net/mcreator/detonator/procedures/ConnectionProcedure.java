package net.mcreator.detonator.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;

import net.mcreator.minecraft.link.event.LinkDeviceConnectedEvent;
import net.mcreator.minecraft.link.devices.PinMode;
import net.mcreator.minecraft.link.CurrentDevice;
import net.mcreator.detonator.DetonatorModElements;

import java.util.Map;
import java.util.Collections;

@DetonatorModElements.ModElement.Tag
public class ConnectionProcedure extends DetonatorModElements.ModElement {
	public ConnectionProcedure(DetonatorModElements instance) {
		super(instance, 1);
		MinecraftForge.EVENT_BUS.register(this);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		CurrentDevice.pinMode((int) 2, PinMode.IN);
	}

	@SubscribeEvent
	public void onLinkDeviceConnected(LinkDeviceConnectedEvent event) {
		this.executeProcedure(Collections.emptyMap());
	}
}
