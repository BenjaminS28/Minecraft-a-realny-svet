package net.mcreator.snapshot.procedures;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;

import net.mcreator.snapshot.SnapshotModElements;
import net.mcreator.snapshot.SnapshotMod;
import net.mcreator.minecraft.link.CurrentDevice;

import java.util.Map;

@SnapshotModElements.ModElement.Tag
public class DayOrNightProcedureProcedure extends SnapshotModElements.ModElement {
	public DayOrNightProcedureProcedure(SnapshotModElements instance) {
		super(instance, 36);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				SnapshotMod.LOGGER.warn("Failed to load dependency world for procedure DayOrNightProcedure!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		if ((!((world instanceof World) ? ((World) world).isDaytime() : false))) {
			CurrentDevice.digitalWrite((int) 4, ((true)) ? (byte) 1 : (byte) 0);
		} else {
			CurrentDevice.digitalWrite((int) 4, ((false)) ? (byte) 1 : (byte) 0);
		}
	}
}
