package net.mcreator.hp.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.entity.Entity;

import net.mcreator.minecraft.link.devices.PinMode;
import net.mcreator.minecraft.link.CurrentDevice;
import net.mcreator.hp.HpModElements;

import java.util.Map;
import java.util.HashMap;

@HpModElements.ModElement.Tag
public class ConnectionProcedure extends HpModElements.ModElement {
	public ConnectionProcedure(HpModElements instance) {
		super(instance, 1);
		MinecraftForge.EVENT_BUS.register(this);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		CurrentDevice.pinMode((int) 13, PinMode.OUT);
		CurrentDevice.pinMode((int) 12, PinMode.OUT);
		CurrentDevice.pinMode((int) 11, PinMode.OUT);
		CurrentDevice.pinMode((int) 10, PinMode.OUT);
		CurrentDevice.pinMode((int) 9, PinMode.OUT);
		CurrentDevice.pinMode((int) 8, PinMode.OUT);
		CurrentDevice.pinMode((int) 7, PinMode.OUT);
		CurrentDevice.pinMode((int) 6, PinMode.OUT);
		CurrentDevice.pinMode((int) 5, PinMode.OUT);
		CurrentDevice.pinMode((int) 4, PinMode.OUT);
	}

	@SubscribeEvent
	public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		Entity entity = event.getPlayer();
		Map<String, Object> dependencies = new HashMap<>();
		dependencies.put("x", entity.getPosX());
		dependencies.put("y", entity.getPosY());
		dependencies.put("z", entity.getPosZ());
		dependencies.put("world", entity.world);
		dependencies.put("entity", entity);
		dependencies.put("event", event);
		this.executeProcedure(dependencies);
	}
}
