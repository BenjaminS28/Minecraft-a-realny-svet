package net.mcreator.hp.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.minecraft.link.CurrentDevice;
import net.mcreator.hp.HpModElements;
import net.mcreator.hp.HpMod;

import java.util.Map;
import java.util.HashMap;

@HpModElements.ModElement.Tag
public class HP2Procedure extends HpModElements.ModElement {
	public HP2Procedure(HpModElements instance) {
		super(instance, 5);
		MinecraftForge.EVENT_BUS.register(this);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				HpMod.LOGGER.warn("Failed to load dependency entity for procedure HP2!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double Counter = 0;
		if ((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > 16)) {
			Counter = (double) 0;
			while ((!((Counter) == 120))) {
				Counter = (double) ((Counter) + 1);
			}
			CurrentDevice.digitalWrite((int) 5, ((true)) ? (byte) 1 : (byte) 0);
		} else {
			Counter = (double) 0;
			while ((!((Counter) == 120))) {
				Counter = (double) ((Counter) + 1);
			}
			CurrentDevice.digitalWrite((int) 5, ((false)) ? (byte) 1 : (byte) 0);
		}
	}

	@SubscribeEvent
	public void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Entity entity = event.player;
			World world = entity.world;
			double i = entity.getPosX();
			double j = entity.getPosY();
			double k = entity.getPosZ();
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", i);
			dependencies.put("y", j);
			dependencies.put("z", k);
			dependencies.put("world", world);
			dependencies.put("entity", entity);
			dependencies.put("event", event);
			this.executeProcedure(dependencies);
		}
	}
}
